const path = require('path')
const root = __dirname
const srcFolder = path.join(root, "src")
const destFolder = path.join(root, "dist")
// const destFolder = path.join("C:/Program Files (x86)/Common Files/Adobe/CEP/extensions/test")
// const certPath = path.join(destFolder, "cert.p12")
const certPath = path.join("D:/extension-react-3", "pass.p12")

module.exports = {
    extensionBundleId: 'com.adil.HappyBrainsTranslator',
    extensionBundleName: 'com.adil.HappyBrainsTranslator',
    extensionBundleVersion: '1.0.0',
    cepVersion: '7.0',
    panelName: 'HappyBrainsTranslator',
    width: '400',
    height: '500',
    root: root,
    sourceFolder: srcFolder,
    destinationFolder: destFolder,
    certificate : {
        customCert: {
            path: "",
            password: "",
            // path: certPath,
            // password: 'AZer325123'
        },
        selfSign: {
            country: 'US',
            province: 'CA',
            org: 'org',
            name: 'name',
            password: 'password',
            locality: 'locality',
            orgUnit: 'orgUnit',
            email: 'your@email.com',
            output: certPath
        }

    }

}
