import React from "react";
import store from "./redux/store";
import "antd/dist/antd.css";
import "./index.css";
import Vengeancemma from "./compositons/Vengeancemma";
import { Provider } from "react-redux";

export default function App() {
  return (
    <React.Fragment>
      <Provider store={store}>
        <Vengeancemma />
      </Provider>
    </React.Fragment>
  );
}
