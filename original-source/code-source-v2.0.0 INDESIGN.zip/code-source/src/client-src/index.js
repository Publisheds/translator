/**
 * @author Tomer Riko Shalev
 */
 import "babel-polyfill";
import React from 'react'
import ReactDOM from 'react-dom'
import 'regenerator-runtime/runtime'
import '../session-src/index'
import App from './App.jsx'

// if (window.cep) {
//     try {
//         window.fs = require('fs');
//         window.path = require('path');
//     }
//     catch (err) {
//         console.log("🚀 ~ file: index.js ~ line 16 ~ err", err)

//     }
// }


ReactDOM.render(<App />,
    document.getElementById('root')
)
